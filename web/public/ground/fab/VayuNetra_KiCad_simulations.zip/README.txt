VayuNetra node - KiCad simulation projects (KiCad 7 or 8, built-in ngspice simulator)

gas/   vn_gas_sim.kicad_pro    TGS2600 measurement chain of the carrier board
droop/ vn_droop_sim.kicad_pro  Battery -> Heltec supply during a LoRa transmission

How to run:
1. Open the .kicad_pro in KiCad, then open the schematic.
2. Inspect > Simulator (KiCad 8: also from the toolbar).
3. Press Run (the .tran command is already on the sheet).
4. Add Signals: V(/AIN0) for gas, V(/HELTEC_IN) for droop.
Expected: V(/AIN0) settles to about 0.387 V, 1.6 ms after the 5 V step at 0.5 ms.
          V(/HELTEC_IN) lowest point about 3.11 V during the transmission burst.
Edit R1 (gas sensor resistance) or V1 / R4 (battery voltage / fuse) and run again.
