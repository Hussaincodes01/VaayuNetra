VayuNetra carrier board - 3D view in KiCad

1. Unzip and open vn_carrier.kicad_pro in KiCad (7 or newer).
2. Open the PCB (vn_carrier.kicad_pcb).
3. View > 3D Viewer (shortcut Alt+3).
All 3D models are inside the 3dmodels folder and are referenced as ${KIPRJMOD}/3dmodels/...,
so nothing else needs to be installed. The Heltec V3, GY-ADS1115 and GY-BME280 models are
simplified stand-ins with real outline sizes, sitting on 8.5 mm female sockets.
vn_carrier_assembled.step: whole populated board for FreeCAD / Fusion / enclosure design.
