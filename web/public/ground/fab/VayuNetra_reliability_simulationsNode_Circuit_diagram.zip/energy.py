"""Hour-by-hour energy + battery-temperature simulation of one carrier-board node on real Indian weather.
Inputs: daily solar radiation (MJ/m2), Tmax, Tmin (Open-Meteo-derived dataset on Hugging Face: AkshayKarthick/india-weather-air-quality)."""
import numpy as np, pandas as pd, itertools, json
def load_city(city):
    if city=='Delhi':
        d=pd.read_csv('../data/delhi_2022-04-09.csv'); d.index=pd.date_range('2022-04-09',periods=len(d))
        return d.loc['2022-05-21':'2023-05-20'],28.61
    d=pd.read_csv('../data/mumbai_2025-05-01.csv'); d.index=pd.date_range('2025-05-01',periods=len(d)); return d,19.08
def hourly(d,lat):
    rows=[]
    for day,r in d.iterrows():
        doy=day.dayofyear; dec=np.radians(23.45*np.sin(np.radians(360*(284+doy)/365)))
        h=np.arange(24)+0.5; ha=np.radians(15*(h-12.0))
        cz=np.sin(np.radians(lat))*np.sin(dec)+np.cos(np.radians(lat))*np.cos(dec)*np.cos(ha); cz=np.clip(cz,0,None)
        G=r.rad/3.6*1000*cz/cz.sum()            # W/m2 each hour (Wh/m2 per hour)
        # air temperature: min at 06:00, max at 15:00 (cosine segments)
        T=np.where((h>=6)&(h<=15), r.tmin+(r.tmax-r.tmin)*(1-np.cos(np.pi*(h-6)/9))/2,
                   np.where(h>15, r.tmax-(r.tmax-r.tmin)*(1-np.cos(np.pi*(h-15)/15))/2, r.tmin+(r.tmax-r.tmin)*(1+np.cos(np.pi*(h+9)/15))/2))
        for i in range(24): rows.append((day+pd.Timedelta(hours=i),G[i],T[i]))
    return pd.DataFrame(rows,columns=['t','G','T']).set_index('t')
ENCL={'white box, shaded under panel':0.006,'white box, in sun':0.012,'grey/black box, in sun':0.025}
def run(city,panel_W=6,cells=3,mcu_mA=50,pm=False,soil=0.85,age=1.0,encl='white box, shaded under panel',seed=None):
    d,lat=load_city(city); hw=hourly(d,lat)
    cap=cells*2.6*3.65*age                     # Wh (2600 mAh cells)
    E=cap; Vb=3.7
    heater=0.210/0.85; mt_q=0.008; misc=0.002
    pmW=(0.5*30/300+0.001)/0.85 if pm else 0
    out=[]; Tb_prev=None; node_on=True; heater_on=True
    for t,(G,T) in hw.iterrows():
        Tb=T+ENCL[encl]*G; Tb=Tb if Tb_prev is None else Tb_prev+0.6*(Tb-Tb_prev); Tb_prev=Tb   # ~1 h thermal lag
        Tc=T+G/800*25
        P_in=panel_W*G/1000*(1-0.004*(Tc-25))*soil*0.97*0.85   # CN3791 MPPT ~85 % + wiring
        soc=E/cap
        # firmware power policy
        if soc<0.08: node_on=False
        if soc>0.20: node_on=True
        heater_on = node_on and soc>0.25
        load=(mcu_mA/1000*Vb if node_on else 0.0002)+(heater if heater_on else 0)+(pmW if node_on else 0)+(mt_q if node_on else 0)+misc
        charging=P_in>0.05 and E<cap
        E=min(cap,max(0,E+P_in-load))
        out.append((t,soc,node_on,heater_on,Tb,charging and Tb>45,charging and Tb>60,P_in,load))
    o=pd.DataFrame(out,columns=['t','soc','node','heater','Tb','chg45','chg60','Pin','load']).set_index('t')
    return o
if __name__=='__main__':
    res=[]
    for city in ['Delhi','Mumbai']:
        for panel,cells,mcu,pm in itertools.product([6,10],[2,3],[50,12],[False,True]):
            o=run(city,panel,cells,mcu,pm)
            res.append(dict(city=city,panel_W=panel,cells=cells,mcu_mA=mcu,pm=pm,
                gas_uptime=round(100*o.heater.mean(),1),mesh_uptime=round(100*o.node.mean(),1),min_soc=round(100*o.soc.min()),
                days_gas_off=int((o.heater.resample('D').mean()<0.5).sum()),load_Wh_day=round(o.load.mean()*24,1),harvest_Wh_day=round(o.Pin.mean()*24,1)))
    df=pd.DataFrame(res); df.to_csv('energy_results.csv',index=False)
    pd.set_option('display.width',200); print(df.to_string(index=False))
    # stress: dusty panel never cleaned + aged battery
    st=[]
    for city in ['Delhi','Mumbai']:
        for panel,cells in [(6,3),(10,3)]:
            o=run(city,panel,cells,12,False,soil=0.65,age=0.75)
            st.append(dict(city=city,panel_W=panel,cells=cells,gas_uptime=round(100*o.heater.mean(),1),mesh_uptime=round(100*o.node.mean(),1),min_soc=round(100*o.soc.min())))
    print('\nSTRESS (soiling 35 %, battery at 75 % capacity, power-saving firmware):'); print(pd.DataFrame(st).to_string(index=False))
    # thermal: battery temperature by enclosure (Delhi year)
    th=[]
    for e in ENCL:
        o=run('Delhi',6,3,12,False,encl=e)
        th.append(dict(enclosure=e,max_batt_C=round(o.Tb.max(),1),hours_above_45C=int((o.Tb>45).sum()),charging_hours_above_45C=int(o.chg45.sum()),hours_above_60C=int((o.Tb>60).sum())))
    print('\nTHERMAL (Delhi, 1 year):'); print(pd.DataFrame(th).to_string(index=False))
    pd.DataFrame(st).to_csv('energy_stress.csv',index=False); pd.DataFrame(th).to_csv('thermal_results.csv',index=False)
