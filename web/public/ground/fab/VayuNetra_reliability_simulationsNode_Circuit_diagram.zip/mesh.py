"""Discrete-event simulation of a Meshtastic-style managed-flooding LoRa mesh at 865-867 MHz.
Physical layer: log-distance path loss + per-link log-normal shadowing + per-packet fading, SX1262 sensitivities,
capture effect (6 dB), half-duplex radios, listen-before-talk with random back-off, SNR-weighted rebroadcast delay."""
import numpy as np, heapq, math, itertools, pandas as pd, json
SENS={7:-124.0,8:-127.0,9:-129.5,10:-132.0,11:-134.5,12:-137.0}   # dBm @125 kHz
def airtime(pl,sf,bw=125e3,cr=1,pre=16):
    ts=(2**sf)/bw; de=1 if ts>0.016 else 0
    n=8+max(math.ceil((8*pl-4*sf+28+16)/(4*(sf-2*de)))*(cr+4),0)
    return (pre+4.25)*ts+n*ts
def topo(kind,rng):
    if kind=='landfill ring (12 nodes)':
        a,b=300,200; ang=np.linspace(0,2*np.pi,12,endpoint=False)
        P=np.c_[a*np.cos(ang),b*np.sin(ang)]; gw=np.array([450.0,0.0]); n=2.9
    else:  # city ward 5x5 grid, 250 m spacing, gateway on a school roof at one edge
        g=np.arange(5)*250.0; P=np.array([(x,y) for x in g for y in g]); gw=np.array([500.0,-120.0]); n=3.3
    return np.vstack([P,gw]),n
def sim(kind,sf,bw=125e3,dur=7200,burst=False,dead=0,seed=0,txp=20,period=300,payload=60):
    rng=np.random.default_rng(seed)
    P,n=topo(kind,rng); N=len(P); G=N-1
    D=np.hypot(*(P[:,None,:]-P[None,:,:]).transpose(2,0,1))+1
    shadow=rng.normal(0,6,(N,N)); shadow=(shadow+shadow.T)/2
    gain=txp+3-1+3-1   # tx, ant, cable, rx ant, cable
    rssi_mean=gain-(31.2+10*n*np.log10(D))+shadow
    sens=SENS[sf]+(0 if bw==125e3 else -10*np.log10(bw/125e3)*-1)   # wider BW -> worse sensitivity
    alive=np.ones(N,bool)
    if dead: alive[rng.choice(G,dead,replace=False)]=False
    ta=airtime(payload,sf,bw); slot=ta/8
    ev=[]; seq=itertools.count()
    origin={}
    def push(t,kind_,*a): heapq.heappush(ev,(t,next(seq),kind_,a))
    pid=itertools.count()
    for i in range(G):
        if not alive[i]: continue
        t0=rng.uniform(0,period)
        while t0<dur:
            push(t0,'gen',i,next(pid)); t0+=period*rng.uniform(0.9,1.1)
    if burst:
        for i in range(G):
            if alive[i]: push(rng.uniform(dur/2,dur/2+10),'gen',i,next(pid))
    txs=[]   # (start,end,node,pid,hops)
    busy_until=np.zeros(N); txtime=np.zeros(N)
    seen=[set() for _ in range(N)]; pending={}  # (node,pid)->scheduled
    got={}  # pid -> first time at gateway
    def start_tx(t,i,p,h,tries=0):
        # listen before talk: channel busy if any audible ongoing tx
        audible=[x for x in txs if x[0]<=t<x[1] and rssi_mean[x[2],i]>sens-6]
        if (audible or busy_until[i]>t) and tries<6:
            push(t+slot*rng.integers(1,16),'tx',i,p,h,tries+1); return
        e=t+ta; txs.append((t,e,i,p,h)); busy_until[i]=e; txtime[i]+=ta
        push(e,'end',len(txs)-1)
    while ev:
        t,_,k,a=heapq.heappop(ev)
        if k=='gen':
            i,p=a; origin[p]=(i,t); seen[i].add(p); start_tx(t,i,p,3)
        elif k=='tx':
            i,p,h,tr=a
            if pending.get((i,p))=='cancel': continue
            start_tx(t,i,p,h,tr)
        elif k=='end':
            s,e,i,p,h=txs[a[0]]
            for j in range(N):
                if j==i or not alive[j]: continue
                r=rssi_mean[i,j]+rng.normal(0,2)
                if r<sens: continue
                if any(x[2]==j and x[0]<e and x[1]>s for x in txs): continue   # half duplex
                interf=[10**((rssi_mean[x[2],j])/10) for x in txs if x is not txs[a[0]] and x[0]<e and x[1]>s and x[2]!=j]
                if interf and r-10*np.log10(sum(interf))<6: continue
                if j==G:
                    got.setdefault(p,e); continue
                if p in seen[j]:
                    if pending.get((j,p))=='wait': pending[(j,p)]='cancel'   # heard a rebroadcast: suppress own
                    continue
                seen[j].add(p)
                if h>1:
                    snr=r-(-117)
                    cw=int(np.interp(snr,[-20,10],[3,8]))
                    pending[(j,p)]='wait'
                    push(e+slot*rng.integers(0,2**cw),'tx',j,p,h-1,0)
    gen=[p for p,(i,t) in origin.items()]
    lat=[got[p]-origin[p][1] for p in gen if p in got]
    bp=[p for p,(i,t) in origin.items() if burst and dur/2<=t<=dur/2+10]
    return dict(pdr=100*len(lat)/len(gen), lat_med=np.median(lat) if lat else np.nan, lat95=np.percentile(lat,95) if lat else np.nan,
                burst_pdr=(100*sum(p in got for p in bp)/len(bp)) if bp else np.nan,
                max_duty=100*txtime[:G].max()/dur, airtime_ms=ta*1000)
if __name__=='__main__':
    rows=[]
    cases=[('SF7 / 125 kHz',7,125e3),('SF9 / 125 kHz (LITE_FAST)',9,125e3),('SF10 / 125 kHz (LITE_SLOW)',10,125e3),('SF11 / 125 kHz (LONG_MODERATE)',11,125e3),('SF11 / 250 kHz (LONG_FAST, Meshtastic IN default)',11,250e3)]
    for kind in ['landfill ring (12 nodes)','city ward grid (25 nodes)']:
        for name,sf,bw in cases:
            for dead in [0,2]:
                R=[sim(kind,sf,bw,dur=3600,burst=True,dead=dead,seed=s) for s in range(12)]
                df=pd.DataFrame(R)
                rows.append(dict(topology=kind,radio=name,dead_nodes=dead,airtime_ms=round(df.airtime_ms[0]),
                    delivery_pct=round(df.pdr.mean(),1),worst_seed_pct=round(df.pdr.min(),1),alarm_burst_pct=round(df.burst_pdr.mean(),1),
                    latency_median_s=round(df.lat_med.mean(),2),latency_p95_s=round(df.lat95.mean(),2),max_node_duty_pct=round(df.max_duty.max(),2)))
                print(rows[-1],flush=True)
    pd.DataFrame(rows).to_csv('mesh_results.csv',index=False)
