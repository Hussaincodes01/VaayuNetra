"""ngspice runs for the carrier board: (1) TGS2600 chain, (2) Monte Carlo of the gas reading, (3) VBAT droop during LoRa TX."""
import subprocess, re, numpy as np, json
def ng(netlist, ctrl):
    src=netlist+"\n.control\nset noaskquit\n"+ctrl+"\nquit\n.endc\n.end\n"
    open('/tmp/claude-0/_n.cir','w').write(src)
    out=subprocess.run(['ngspice','-b','/tmp/claude-0/_n.cir'],capture_output=True,text=True).stdout
    return out
def vop(netlist,node):
    o=ng(netlist,f"op\nprint v({node})")
    return float(re.search(rf'v\({node}\)\s*=\s*([-\d.eE+]+)',o).group(1))
GAS="""* gas chain
V5 v5 0 {v5}
Rs v5 gas_s {rs}
R3 gas_s gas_m {r3}
R4 gas_m 0 {r4}
R5 gas_m ain0 1k
C3 ain0 0 100n
Rads ain0 0 6Meg
"""
res={}
# 1) sweep
rows=[]
for rs in [1e3,2e3,5e3,10e3,20e3,30e3,50e3,90e3,150e3,200e3]:
    a=vop(GAS.format(v5=5,rs=rs,r3=2200,r4=2700),'ain0'); b=vop(GAS.format(v5=5,rs=rs*1.01,r3=2200,r4=2700),'ain0')
    rows.append((rs/1e3,round(a,4),round((a-b)*1000,2),round((a-b)/62.5e-6)))
res['sweep']=rows
print('Rs kOhm | V_ain0 | mV per 1% Rs change | ADS1115 LSBs (2.048 V range)')
for r in rows: print(r)
# step response (settling)
o=ng(GAS.format(v5=5,rs=30e3,r3=2200,r4=2700).replace('V5 v5 0 5','V5 v5 0 PULSE(0 5 0 1u 1u 1 2)'),"tran 10u 5m\nmeas tran t99 when v(ain0)=0.3827 rise=1")
m=re.search(r't99\s*=\s*([-\d.eE+]+)',o); res['settle_99pct_ms']=float(m.group(1))*1e3 if m else None
print('RC settling to 99 %:',res['settle_99pct_ms'],'ms')
# 2) Monte Carlo: 1 % resistors, MT3608 module set by trimmer: 5 V +/-3 %, AIN3 divider 1 %, ADS gain error 0.15 %
rng=np.random.default_rng(1); N=400; err_nom=[]; err_ratio=[]
RS=30e3
for i in range(N):
    r3=2200*(1+rng.normal(0,0.01/3)); r4=2700*(1+rng.normal(0,0.01/3)); v5=5*(1+rng.uniform(-0.03,0.03))
    g=1+rng.normal(0,0.0015/3)
    va=vop(GAS.format(v5=v5,rs=RS,r3=r3,r4=r4),'ain0')*g
    rt=100e3*(1+rng.normal(0,0.01/3)); rb=100e3*(1+rng.normal(0,0.01/3))
    v5m=v5*rb/(rt+rb)*g*2
    vrl=va*4900/2700
    err_nom.append((4900*(5.0/vrl-1)-RS)/RS*100)
    err_ratio.append((4900*(v5m/vrl-1)-RS)/RS*100)
res['mc']=dict(N=N,abs_err_assumed_5V_p95=round(float(np.percentile(np.abs(err_nom),95)),2),abs_err_ratiometric_p95=round(float(np.percentile(np.abs(err_ratio),95)),2))
print('Monte Carlo |error in Rs| 95th pct: assume 5.00 V =',res['mc']['abs_err_assumed_5V_p95'],'%   ratiometric (AIN3) =',res['mc']['abs_err_ratiometric_p95'],'%')
# 3) VBAT droop during LoRa TX + PMS fan start, battery near firmware cut-off
DROOP="""* battery -> BMS -> cable -> PTC -> VBAT bus -> Heltec + MT3608
Vocv bat 0 {vocv}
Rcell bat b1 {rcell}
Rbms b1 b2 0.04
Rcab b2 b3 0.073
Rptc b3 vbat {rptc}
C1 vbat c1n 470u
Rc1 c1n 0 0.15
Rh vbat hin 0.072
Ih hin 0 PWL(0 0.05 10m 0.05 10.1m 0.20 410m 0.20 410.1m 0.05 600m 0.05)
Bboost vbat 0 I=(0.247+{pm}*0.59*(time>5m)*(time<300m))/max(v(vbat),2.5)
.ic v(vbat)={vocv}
"""
rows=[]
for vocv in [3.3,3.5,3.7]:
    for cells,rcell in [(2,0.04),(3,0.027)]:
        for rptc in [0.1,0.25]:
            for pm in [0,1]:
                o=ng(DROOP.format(vocv=vocv,rcell=rcell,rptc=rptc,pm=pm),"tran 0.1m 600m uic\nmeas tran vmin MIN v(hin)")
                v=float(re.search(r'vmin\s*=\s*([-\d.eE+]+)',o).group(1))
                rows.append(dict(battery_V=vocv,cells=cells,ptc_ohm=rptc,pm_fan_start=bool(pm),min_V_at_Heltec=round(v,3)))
res['droop']=rows
import pandas as pd; df=pd.DataFrame(rows); print(df.to_string(index=False))
json.dump(res,open('spice_results.json','w'),indent=1)
